package com.ur.urcap.examples.ellipseswing;

import java.awt.Dimension;

public abstract class Style {

	public abstract int getVerticalSpacing();

	public abstract int getHorizontalIndent();

	public abstract Dimension getButtonSize();

}
